/* eslint-disable no-unused-vars */
export var TemplatePreset;
(function (TemplatePreset) {
    TemplatePreset["CONE"] = "cone";
    TemplatePreset["SBT"] = "sbt";
    TemplatePreset["MBT"] = "mbt";
    TemplatePreset["LBT"] = "lbt";
})(TemplatePreset || (TemplatePreset = {}));
