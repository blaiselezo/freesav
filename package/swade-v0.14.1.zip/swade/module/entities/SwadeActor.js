/* eslint-disable no-unused-vars */
import SwadeDice from "../dice.js";
/**
 * @noInheritDoc
 */
export default class SwadeActor extends Actor {
    /**
     * @override
     * Extends data from base Actor class
     */
    prepareData() {
        this.data = duplicate(this['_data']);
        if (!this.data.img)
            this.data.img = CONST.DEFAULT_TOKEN;
        if (!this.data.name)
            this.data.name = 'New ' + this.entity;
        this.prepareBaseData();
        const shouldAutoCalcToughness = getProperty(this.data, 'data.details.autoCalcToughness') &&
            this.data.type !== 'vehicle';
        const toughnessKey = 'data.stats.toughness.value';
        const armorKey = 'data.stats.toughness.armor';
        this.prepareEmbeddedEntities();
        this.applyActiveEffects();
        if (shouldAutoCalcToughness) {
            const adjustedToughness = getProperty(this.data, toughnessKey);
            const adjustedArmor = getProperty(this.data, armorKey);
            setProperty(this.data, toughnessKey, adjustedToughness + adjustedArmor);
        }
        this.prepareDerivedData();
    }
    /**
     * @override
     */
    prepareBaseData() {
        //auto calculations
        const shouldAutoCalcToughness = getProperty(this.data, 'data.details.autoCalcToughness') &&
            this.data.type !== 'vehicle';
        if (shouldAutoCalcToughness) {
            const toughnessKey = 'data.stats.toughness.value';
            const armorKey = 'data.stats.toughness.armor';
            setProperty(this.data, toughnessKey, this.calcToughness(false));
            setProperty(this.data, armorKey, this.calcArmor());
        }
    }
    /**
     * @override
     */
    prepareDerivedData() {
        //return early for Vehicles
        if (this.data.type === 'vehicle')
            return;
        //modify pace with wounds
        if (game.settings.get('swade', 'enableWoundPace')) {
            const wounds = getProperty(this.data, 'data.wounds.value');
            const pace = getProperty(this.data, 'data.stats.speed.value');
            let adjustedPace = parseInt(pace) - parseInt(wounds);
            if (adjustedPace < 1)
                adjustedPace = 1;
            setProperty(this.data, 'data.stats.speed.value', adjustedPace);
        }
        //die type bounding for attributes
        let attributes = getProperty(this.data, 'data.attributes');
        for (let attribute in attributes) {
            let sides = getProperty(this.data, `data.attributes.${attribute}.die.sides`);
            if (sides < 4 && sides !== 1) {
                setProperty(this.data, `data.attributes.${attribute}.die.sides`, 4);
            }
            else if (sides > 12) {
                setProperty(this.data, `data.attributes.${attribute}.die.sides`, 12);
            }
        }
    }
    /* -------------------------------------------- */
    /*  Getters
    /* -------------------------------------------- */
    get isWildcard() {
        if (this.data.type === 'vehicle') {
            return false;
        }
        else {
            return (getProperty(this.data, 'data.wildcard') ||
                this.data.type === 'character');
        }
    }
    /* -------------------------------------------- */
    /*  Socket Listeners and Handlers
    /* -------------------------------------------- */
    /** @override */
    static async create(data, options = {}) {
        let link = false;
        if (data.type === 'character') {
            link = true;
        }
        data.token = data.token || {};
        mergeObject(data.token, {
            vision: true,
            actorLink: link,
        }, { overwrite: false });
        return super.create(data, options);
    }
    /* -------------------------------------------- */
    /*  Rolls                                       */
    /* -------------------------------------------- */
    rollAttribute(abilityId, options = { event: null }) {
        const label = CONFIG.SWADE.attributes[abilityId].long;
        let actorData = this.data;
        const abl = actorData.data.attributes[abilityId];
        let finalRoll = new Roll('');
        let rollMods = this._buildTraitRollModifiers(abl, options);
        let attrRoll = new Roll('');
        attrRoll.terms.push(this._buildTraitDie(abl.die.sides, game.i18n.localize(label)));
        if (rollMods.length !== 0) {
            rollMods.forEach((m) => attrRoll.terms.push(m.value));
        }
        //If the Actor is a wildcard the build a dicepool, otherwise build a Roll
        if (this.isWildcard) {
            let wildRoll = new Roll('');
            let wildDie = this._buildTraitDie(abl['wild-die'].sides, game.i18n.localize('SWADE.WildDie'));
            wildRoll.terms.push(wildDie);
            let wildCardPool = new DicePool({
                rolls: [attrRoll, wildRoll],
                modifiers: ['kh'],
            });
            if (rollMods.length !== 0) {
                rollMods.forEach((m) => wildRoll.terms.push(m.value));
            }
            finalRoll.terms.push(wildCardPool);
        }
        else {
            finalRoll = attrRoll;
        }
        if (options.suppressChat) {
            return finalRoll;
        }
        //Build Flavour
        let flavour = '';
        if (rollMods.length !== 0) {
            rollMods.forEach((v) => {
                flavour = flavour.concat(`<br>${v.label}: ${v.value}`);
            });
        }
        // Roll and return
        return SwadeDice.Roll({
            roll: finalRoll,
            data: actorData,
            speaker: ChatMessage.getSpeaker({ actor: this }),
            flavor: `${game.i18n.localize(label)} ${game.i18n.localize('SWADE.AttributeTest')}${flavour}`,
            title: `${game.i18n.localize(label)} ${game.i18n.localize('SWADE.AttributeTest')}`,
            actor: this,
            allowGroup: true,
            flags: { swade: { colorMessage: true } },
        });
    }
    rollSkill(skillId, options = { event: null }, tempSkill) {
        if (!options.rof)
            options.rof = 1;
        let skill;
        skill = this.items.find((i) => i.id == skillId);
        if (tempSkill) {
            skill = tempSkill;
        }
        if (!skill) {
            return;
        }
        let skillData = getProperty(skill, 'data.data');
        let skillRoll = null;
        let rollMods = [];
        if (options.rof && options.rof > 1) {
            skillRoll = this._handleComplexSkill(skill, options);
            rollMods = skillRoll[1];
        }
        else {
            skillRoll = this._handleSimpleSkill(skill, options);
            rollMods = skillRoll[1];
        }
        //Build Flavour
        let flavour = '';
        if (options.flavour) {
            flavour = ` - ${options.flavour}`;
        }
        if (rollMods.length !== 0) {
            rollMods.forEach((v) => {
                flavour = flavour.concat(`<br>${v.label}: ${v.value}`);
            });
        }
        if (options.suppressChat) {
            return skillRoll[0];
        }
        // Roll and return
        return SwadeDice.Roll({
            roll: skillRoll[0],
            data: skillData,
            speaker: ChatMessage.getSpeaker({ actor: this }),
            flavor: `${skill.name} ${game.i18n.localize('SWADE.SkillTest')}${flavour}`,
            title: `${skill.name} ${game.i18n.localize('SWADE.SkillTest')}`,
            actor: this,
            allowGroup: true,
            flags: { swade: { colorMessage: true } },
        });
    }
    async makeUnskilledAttempt(options = { event: null }) {
        let tempSkill = new Item({
            name: game.i18n.localize('SWADE.Unskilled'),
            type: 'skill',
            flags: {},
            data: {
                die: {
                    sides: 4,
                    modifier: '-2',
                },
                'wild-die': {
                    sides: 6,
                },
            },
        }, { temporary: true });
        return this.rollSkill('', options, tempSkill);
    }
    async spendBenny() {
        let message = await renderTemplate(CONFIG.SWADE.bennies.templates.spend, {
            target: this,
            speaker: game.user,
        });
        let chatData = {
            content: message,
        };
        if (game.settings.get('swade', 'notifyBennies')) {
            ChatMessage.create(chatData);
        }
        let actorData = this.data;
        if (actorData.data.bennies.value > 0) {
            await this.update({
                'data.bennies.value': actorData.data.bennies.value - 1,
            });
        }
    }
    async getBenny() {
        let message = await renderTemplate(CONFIG.SWADE.bennies.templates.add, {
            target: this,
            speaker: game.user,
        });
        let chatData = {
            content: message,
        };
        if (game.settings.get('swade', 'notifyBennies')) {
            ChatMessage.create(chatData);
        }
        let actorData = this.data;
        await this.update({
            'data.bennies.value': actorData.data.bennies.value + 1,
        });
    }
    /**
     * Reset the bennies of the Actor to their default value
     * @param displayToChat display a message to chat
     */
    async refreshBennies(displayToChat = true) {
        if (displayToChat) {
            let message = await renderTemplate(CONFIG.SWADE.bennies.templates.refresh, {
                target: this,
                speaker: game.user,
            });
            let chatData = {
                content: message,
            };
            ChatMessage.create(chatData);
        }
        let actorData = this.data;
        await this.update({ 'data.bennies.value': actorData.data.bennies.max });
    }
    /**
     * Calculates the total Wound Penalties
     */
    calcWoundPenalties() {
        let retVal = 0;
        const wounds = parseInt(getProperty(this.data, 'data.wounds.value'));
        let ignoredWounds = parseInt(getProperty(this.data, 'data.wounds.ignored'));
        if (isNaN(ignoredWounds))
            ignoredWounds = 0;
        if (!isNaN(wounds)) {
            if (wounds > 3) {
                retVal += 3;
            }
            else {
                retVal += wounds;
            }
            if (retVal - ignoredWounds < 0) {
                retVal = 0;
            }
            else {
                retVal -= ignoredWounds;
            }
        }
        return retVal * -1;
    }
    /**
     * Calculates the total Fatigue Penalties
     */
    calcFatiguePenalties() {
        let retVal = 0;
        const fatigue = parseInt(getProperty(this.data, 'data.fatigue.value'));
        if (!isNaN(fatigue))
            retVal -= fatigue;
        return retVal;
    }
    calcStatusPenalties() {
        let retVal = 0;
        if (this.data.data.status.isDistracted) {
            retVal -= 2;
        }
        return retVal;
    }
    /**
     * Function for shorcut roll in item (@str + 1d6)
     * return something like : {agi: "1d8x8+1", sma: "1d6x6", spi: "1d6x6", str: "1d6x6-1", vig: "1d6x6"}
     */
    getRollShortcuts(bAddWildDie = false) {
        let out = {};
        // Attributes
        const attr = this.data.data.attributes;
        for (const name of ['agility', 'smarts', 'spirit', 'strength', 'vigor']) {
            out[name.substring(0, 3)] =
                `1d${attr[name].die.sides}x` +
                    (attr[name].die.modifier[0] != 0
                        ? (['+', '-'].indexOf(attr[name].die.modifier[0]) < 0 ? '+' : '') +
                            attr[name].die.modifier
                        : '') +
                    // wild-die
                    (bAddWildDie && attr[name]['wild-die'].sides
                        ? `+1d${attr[name]['wild-die'].sides}x`
                        : '');
        } //fr
        return out;
    }
    /**
     * Calculates the correct armor value based on SWADE v5.5 and returns that value
     */
    calcArmor() {
        let totalArmorVal = 0;
        let armorList = this.data['items'].filter((i) => {
            let isEquipped = getProperty(i.data, 'equipped');
            let coversTorso = getProperty(i.data, 'locations.torso');
            let isNaturalArmor = getProperty(i.data, 'isNaturalArmor');
            return i.type === 'armor' && isEquipped && !isNaturalArmor && coversTorso;
        });
        armorList.sort((a, b) => {
            const aValue = parseInt(a.data.armor);
            const bValue = parseInt(b.data.armor);
            if (aValue < bValue) {
                return 1;
            }
            if (aValue > bValue) {
                return -1;
            }
            return 0;
        });
        const naturalArmors = this.data['items'].filter((i) => {
            return i.type === 'armor' && getProperty(i.data, 'isNaturalArmor');
        });
        for (const armor of naturalArmors) {
            totalArmorVal += parseInt(armor.data.armor);
        }
        if (armorList.length === 0) {
            return totalArmorVal;
        }
        else if (armorList.length === 1) {
            totalArmorVal = parseInt(armorList[0].data.armor);
        }
        else {
            totalArmorVal =
                parseInt(armorList[0].data.armor) +
                    Math.floor(parseInt(armorList[1].data.armor) / 2);
        }
        return totalArmorVal;
    }
    /**
     * Calculates the Toughness value and returns it, optionally with armor
     * @param includeArmor include armor in final value (true/false). Default is true
     */
    calcToughness(includeArmor = true) {
        let retVal = 0;
        let vigor = getProperty(this.data, 'data.attributes.vigor.die.sides');
        let vigMod = parseInt(getProperty(this.data, 'data.attributes.vigor.die.modifier'));
        let toughMod = parseInt(getProperty(this.data, 'data.stats.toughness.modifier'));
        let size = parseInt(getProperty(this.data, 'data.stats.size'));
        retVal = Math.round(vigor / 2) + 2;
        retVal += size;
        retVal += toughMod;
        if (vigMod > 0) {
            retVal += Math.floor(vigMod / 2);
        }
        if (includeArmor) {
            retVal += this.calcArmor();
        }
        return retVal;
    }
    /**
     * Helper Function for Vehicle Actors, to roll Maneuevering checks
     */
    rollManeuverCheck(event = null) {
        let driverId = getProperty(this.data, 'data.driver.id');
        let driver = game.actors.get(driverId);
        //Return early if no driver was found
        if (!driverId || !driver) {
            return;
        }
        //Get skillname
        let skillName = getProperty(this.data, 'data.driver.skill');
        if (skillName === '') {
            skillName = getProperty(this.data, 'data.driver.skillAlternative');
        }
        let handling = getProperty(this.data, 'data.handling');
        let wounds = this.calcWoundPenalties();
        let totalHandling;
        totalHandling = handling + wounds;
        // Calculate handling
        //Handling is capped at a certain penalty
        if (totalHandling < CONFIG.SWADE.vehicles.maxHandlingPenalty) {
            totalHandling = CONFIG.SWADE.vehicles.maxHandlingPenalty;
        }
        if (totalHandling > 0) {
            totalHandling = `+${totalHandling}`;
        }
        let options = {
            event: event,
            additionalMods: [totalHandling],
        };
        //Find the operating skill
        let skill = driver.items.find((i) => i.type === 'skill' && i.name === skillName);
        if (skill) {
            driver.rollSkill(skill.id, options);
        }
        else {
            driver.makeUnskilledAttempt(options);
        }
    }
    _handleSimpleSkill(skill, options) {
        const skillData = getProperty(skill, 'data.data');
        let skillRoll = new Roll('');
        skillRoll.terms.push(this._buildTraitDie(skillData.die.sides, skill.name));
        if (this.isWildcard) {
            return this._handleComplexSkill(skill, options);
        }
        else {
            let rollMods = this._buildTraitRollModifiers(skillData, options);
            rollMods.forEach((m) => skillRoll.terms.push(m.value));
            return [skillRoll, rollMods];
        }
    }
    _handleComplexSkill(skill, options) {
        if (!options.rof)
            options.rof = 1;
        const skillData = getProperty(skill, 'data.data');
        const rolls = [];
        const rollMods = this._buildTraitRollModifiers(skillData, options);
        for (let i = 0; i < options.rof; i++) {
            let skillRoll = new Roll('');
            let traitDie = this._buildTraitDie(skillData.die.sides, skill.name);
            skillRoll.terms.push(traitDie);
            rollMods.forEach((m) => skillRoll.terms.push(m.value));
            rolls.push(skillRoll);
        }
        let kh = options.rof > 1 ? `kh${options.rof}` : 'kh';
        let dicePool = new DicePool({
            rolls: rolls,
            modifiers: [kh],
        });
        if (this.isWildcard) {
            let wildRoll = new Roll('');
            wildRoll.terms.push(this._buildTraitDie(skillData['wild-die'].sides, game.i18n.localize('SWADE.WildDie')));
            rollMods.forEach((m) => wildRoll.terms.push(m.value));
            dicePool.rolls.push(wildRoll);
        }
        //Conviction Modifier
        if (this.isWildcard &&
            game.settings.get('swade', 'enableConviction') &&
            getProperty(this.data, 'data.details.conviction.active')) {
            for (const r of dicePool.rolls) {
                r.terms.push('+');
                r.terms.push(this._buildTraitDie(6, game.i18n.localize('SWADE.Conv')));
            }
        }
        const finalRoll = new Roll('');
        finalRoll.terms.push(dicePool);
        return [finalRoll, rollMods];
    }
    _buildTraitDie(sides, flavor, modifiers = []) {
        return new Die({
            faces: sides,
            modifiers: ['x', ...modifiers],
            options: { flavor: flavor },
        });
    }
    _buildTraitRollModifiers(data, options) {
        const mods = [];
        //Skill modifier
        let itemMod = parseInt(data.die.modifier);
        if (!isNaN(itemMod) && itemMod !== 0) {
            mods.push({ label: 'Skill Mod', value: itemMod.signedString() });
        }
        // Wound and Fatigue Penalties
        const woundPenalties = this.calcWoundPenalties();
        if (woundPenalties !== 0)
            mods.push({
                label: game.i18n.localize('SWADE.Wounds'),
                value: woundPenalties.signedString(),
            });
        const fatiguePenalties = this.calcFatiguePenalties();
        if (fatiguePenalties !== 0)
            mods.push({
                label: game.i18n.localize('SWADE.Fatigue'),
                value: fatiguePenalties.signedString(),
            });
        const statusPenalties = this.calcStatusPenalties();
        if (statusPenalties !== 0)
            mods.push({
                label: game.i18n.localize('SWADE.Status'),
                value: statusPenalties.signedString(),
            });
        //Additional Mods
        if (options.additionalMods) {
            options.additionalMods.forEach((v) => {
                let value;
                if (typeof v === 'string') {
                    value = v;
                }
                else {
                    value = v.signedString();
                }
                mods.push({ label: game.i18n.localize('SWADE.Addi'), value });
            });
        }
        return [...mods.filter((m) => m.value)];
    }
}
