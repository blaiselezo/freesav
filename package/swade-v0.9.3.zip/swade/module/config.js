export class SWADE {
}
SWADE.ASCII = `███████╗██╗    ██╗ █████╗ ██████╗ ███████╗
██╔════╝██║    ██║██╔══██╗██╔══██╗██╔════╝
███████╗██║ █╗ ██║███████║██║  ██║█████╗  
╚════██║██║███╗██║██╔══██║██║  ██║██╔══╝  
███████║╚███╔███╔╝██║  ██║██████╔╝███████╗
╚══════╝ ╚══╝╚══╝ ╚═╝  ╚═╝╚═════╝ ╚══════╝`;
SWADE.attributes = {
    agility: {
        long: 'SWADE.AttrAgi',
        short: 'SWADE.AttrAgiShort',
    },
    smarts: {
        long: 'SWADE.AttrSma',
        short: 'SWADE.AttrSmaShort',
    },
    spirit: {
        long: 'SWADE.AttrSpr',
        short: 'SWADE.AttrSprShort',
    },
    strength: {
        long: 'SWADE.AttrStr',
        short: 'SWADE.AttrStrShort',
    },
    vigor: {
        long: 'SWADE.AttrVig',
        short: 'SWADE.AttrVigShort',
    },
};
SWADE.statusIcons = {
    shaken: 'icons/svg/daze.svg',
    vulnerable: 'icons/svg/degen.svg',
    distracted: 'icons/svg/stoned.svg',
};
SWADE.init = {
    defaultCardCompendium: 'swade.action-cards',
    cardTable: 'Action Cards',
};
SWADE.packChoices = {};
SWADE.imagedrop = {
    height: 300,
};
SWADE.bennies = {
    templates: {
        refresh: 'systems/swade/templates/chat/benny-refresh.html',
        add: 'systems/swade/templates/chat/benny-add.html',
        spend: 'systems/swade/templates/chat/benny-spend.html',
        gmadd: 'systems/swade/templates/chat/benny-gmadd.html',
    },
};
