export class SWADE {
}
SWADE.ASCII = `███████╗██╗    ██╗ █████╗ ██████╗ ███████╗
██╔════╝██║    ██║██╔══██╗██╔══██╗██╔════╝
███████╗██║ █╗ ██║███████║██║  ██║█████╗  
╚════██║██║███╗██║██╔══██║██║  ██║██╔══╝  
███████║╚███╔███╔╝██║  ██║██████╔╝███████╗
╚══════╝ ╚══╝╚══╝ ╚═╝  ╚═╝╚═════╝ ╚══════╝`;
SWADE.attributes = {
    agility: 'SWADE.AttrAgi',
    smarts: 'SWADE.AttrSma',
    spirit: 'SWADE.AttrSpr',
    strength: 'SWADE.AttrStr',
    vigor: 'SWADE.AttrVig'
};
SWADE.statusIcons = {
    shaken: 'icons/svg/daze.svg',
    vulnerable: 'icons/svg/degen.svg',
    distracted: 'icons/svg/stoned.svg'
};
SWADE.init = {
    cardCompendium: 'swade.action-cards',
    cardTable: 'Action Cards'
};
SWADE.imagedrop = {
    height: 200
};
