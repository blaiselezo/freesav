export var ItemType;
(function (ItemType) {
    ItemType["Weapon"] = "weapon";
    ItemType["Armor"] = "armor";
    ItemType["Shield"] = "shield";
    ItemType["Gear"] = "gear";
    ItemType["Edge"] = "edge";
    ItemType["Hindrance"] = "hindrance";
    ItemType["Skill"] = "skill";
    ItemType["Power"] = "power";
    ItemType["Ability"] = "ability";
})(ItemType || (ItemType = {}));
