export var AbilitySubtype;
(function (AbilitySubtype) {
    AbilitySubtype["Race"] = "race";
    AbilitySubtype["Special"] = "special";
})(AbilitySubtype || (AbilitySubtype = {}));
