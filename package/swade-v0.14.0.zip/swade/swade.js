/* eslint-disable no-unused-vars */
/**
 * This is the TypeScript entry file for Foundry VTT.
 * Author: FloRad
 * Content License: Savage Worlds Fan License
 * Software License: GNU GENERAL PUBLIC LICENSE Version 3
 */
import { getSwadeConeShape } from "./module/cone.js";
import { SWADE } from "./module/config.js";
import SwadeEntityTweaks from "./module/dialog/entity-tweaks.js";
import SwadeActor from "./module/entities/SwadeActor.js";
import SwadeItem from "./module/entities/SwadeItem.js";
import { registerCustomHelpers } from "./module/handlebarsHelpers.js";
import { listenJournalDrop } from "./module/journalDrop.js";
import { preloadHandlebarsTemplates } from "./module/preloadTemplates.js";
import { registerSettings } from "./module/settings.js";
import SwadeCharacterSheet from "./module/sheets/SwadeCharacterSheet.js";
import SwadeItemSheet from "./module/sheets/SwadeItemSheet.js";
import SwadeNPCSheet from "./module/sheets/SwadeNPCSheet.js";
import SwadeVehicleSheet from "./module/sheets/SwadeVehicleSheet.js";
import { rollInitiative, _sortCombatants } from "./module/SwadeCombat.js";
import SwadeHooks from "./module/SwadeHooks.js";
import { SwadeSocketHandler } from "./module/SwadeSocketHandler.js";
import { rollPowerMacro, rollSkillMacro, rollWeaponMacro } from "./module/util.js";
/* ------------------------------------ */
/* Initialize system					          */
/* ------------------------------------ */
Hooks.once('init', () => {
    console.log(`SWADE | Initializing Savage Worlds Adventure Edition\n${SWADE.ASCII}`);
    // Record Configuration Values
    // CONFIG.debug.hooks = true;
    CONFIG.SWADE = SWADE;
    game.swade = {
        SwadeActor,
        SwadeItem,
        SwadeEntityTweaks,
        rollSkillMacro,
        rollWeaponMacro,
        rollPowerMacro,
        sockets: new SwadeSocketHandler(),
    };
    //Register custom Handlebars helpers
    registerCustomHelpers();
    //Overwrite method prototypes
    Combat.prototype.rollInitiative = rollInitiative;
    Combat.prototype._sortCombatants = _sortCombatants;
    MeasuredTemplate.prototype._getConeShape = getSwadeConeShape;
    // Register custom classes
    //CONFIG.Combat.entityClass = SwadeCombat;
    CONFIG.Actor.entityClass = SwadeActor;
    CONFIG.Item.entityClass = SwadeItem;
    // Register custom system settings
    registerSettings();
    // Register sheets
    Actors.unregisterSheet('core', ActorSheet);
    Items.unregisterSheet('core', ItemSheet);
    Actors.registerSheet('swade', SwadeCharacterSheet, {
        types: ['character'],
        makeDefault: true,
        label: 'SWADE.CommunityCharSheet',
    });
    Actors.registerSheet('swade', SwadeNPCSheet, {
        types: ['npc'],
        makeDefault: true,
        label: 'SWADE.CommunityNPCSheet',
    });
    Actors.registerSheet('swade', SwadeVehicleSheet, {
        types: ['vehicle'],
        makeDefault: true,
        label: 'SWADE.CommunityVicSheet',
    });
    Items.registerSheet('swade', SwadeItemSheet, {
        makeDefault: true,
        label: 'SWADE.CommunityItemSheet',
    });
    // Drop a journal image to a tile (for cards)
    listenJournalDrop();
    // Preload Handlebars templates
    CONFIG.SWADE.templates.preloadPromise = preloadHandlebarsTemplates();
    CONFIG.SWADE.templates.preloadPromise.then(() => {
        CONFIG.SWADE.templates.templatesPreloaded = true;
    });
});
/* ------------------------------------ */
/* Setup system							            */
/* ------------------------------------ */
Hooks.once('setup', () => SwadeHooks.onSetup());
/* ------------------------------------ */
/* When ready						              	*/
/* ------------------------------------ */
Hooks.once('ready', async () => SwadeHooks.onReady());
Hooks.on('preCreateItem', (createData, options, userId) => SwadeHooks.onPreCreateItem(createData, options, userId));
Hooks.on('preCreateOwnedItem', (actor, createData, options, userId) => SwadeHooks.onPreCreateOwnedItem(actor, createData, options, userId));
Hooks.on('preCreateActor', async (createData, options, userId) => SwadeHooks.onPreCreateActor(createData, options, userId));
Hooks.on('createActor', async (actor, options, userId) => SwadeHooks.onCreateActor(actor, options, userId));
Hooks.on('renderActorDirectory', (app, html, options) => SwadeHooks.onRenderActorDirectory(app, html, options));
Hooks.on('renderCompendium', async (app, html, data) => SwadeHooks.onRenderCompendium(app, html, data));
Hooks.on('preUpdateActor', (actor, updateData, options, userId) => SwadeHooks.onPreUpdateActor(actor, updateData, options, userId));
Hooks.on('updateActor', (actor, updateData, options, userId) => SwadeHooks.onUpdateActor(actor, updateData, options, userId));
Hooks.on('renderCombatTracker', (app, html, data) => SwadeHooks.onRenderCombatTracker(app, html, data));
Hooks.on('preUpdateCombat', async (combat, updateData, options, userId) => SwadeHooks.onPreUpdateCombat(combat, updateData, options, userId));
Hooks.on('updateCombat', (combat, updateData, options, userId) => SwadeHooks.onUpdateCombat(combat, updateData, options, userId));
Hooks.on('deleteCombat', (combat, options, userId) => SwadeHooks.onDeleteCombat(combat, options, userId));
// Add roll data to the message for formatting of dice pools
Hooks.on('renderChatMessage', async (chatMessage, html, data) => SwadeHooks.onRenderChatMessage(chatMessage, html, data));
Hooks.on('renderChatLog', (app, html, data) => SwadeHooks.onRenderChatLog(app, html, data));
// Add benny management to the player list
Hooks.on('renderPlayerList', async (list, html, options) => SwadeHooks.onRenderPlayerList(list, html, options));
Hooks.on('getUserContextOptions', (html, context) => SwadeHooks.onGetUserContextOptions(html, context));
Hooks.on('getSceneControlButtons', (sceneControlButtons) => SwadeHooks.onGetSceneControlButtons(sceneControlButtons));
Hooks.on('renderChatPopout', (app, html, data) => SwadeHooks.onRenderChatLog(app, html, data));
Hooks.on('dropActorSheetData', (actor, sheet, data) => SwadeHooks.onDropActorSheetData(actor, sheet, data));
Hooks.on('renderCombatantConfig', async (app, html, options) => SwadeHooks.onRenderCombatantConfig(app, html, options));
