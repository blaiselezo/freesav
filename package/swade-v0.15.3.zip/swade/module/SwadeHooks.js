/* eslint-disable no-unused-vars */
import Bennies from "./bennies.js";
import * as chat from "./chat.js";
import { formatRoll } from "./chat.js";
import SwadeTemplate from "./entities/SwadeTemplate.js";
import { ActorType } from "./enums/ActorTypeEnum.js";
import { ItemType } from "./enums/ItemTypeEnum.js";
import { TemplatePreset } from "./enums/TemplatePresetEnum.js";
import { SwadeSetup } from "./setup/setupHandler.js";
import { createActionCardTable, createSwadeMacro } from "./util.js";
export default class SwadeHooks {
    static onSetup() {
        // Do anything after initialization but before ready
        // Localize CONFIG objects once up-front
        const toLocalize = [];
        for (let o of toLocalize) {
            CONFIG.SWADE[o] = Object.entries(CONFIG.SWADE[o]).reduce((obj, e) => {
                obj[e[0]] = game.i18n.localize(e[1]);
                return obj;
            }, {});
        }
    }
    static async onReady() {
        let packChoices = {};
        game.packs
            .filter((p) => p.entity === 'JournalEntry')
            .forEach((p) => {
            packChoices[p.collection] = `${p.metadata.label} (${p.metadata.package})`;
        });
        game.settings.register('swade', 'cardDeck', {
            name: 'Card Deck to use for Initiative',
            scope: 'world',
            type: String,
            config: true,
            default: CONFIG.SWADE.init.defaultCardCompendium,
            choices: packChoices,
            onChange: async (choice) => {
                console.log(`Repopulating action cards Table with cards from deck ${choice}`);
                await createActionCardTable(true, choice);
                ui.notifications.info('Table re-population complete');
            },
        });
        await SwadeSetup.setup();
        Hooks.on('hotbarDrop', (bar, data, slot) => createSwadeMacro(data, slot));
    }
    static onPreCreateItem(createData, options, userId) {
        //Set default image if no image already exists
        if (!createData.img) {
            createData.img = `systems/swade/assets/icons/${createData.type}.svg`;
        }
    }
    static onPreCreateOwnedItem(actor, createData, options, userId) {
        //Set default image if no image already exists
        if (!createData.img) {
            createData.img = `systems/swade/assets/icons/${createData.type}.svg`;
        }
    }
    static onPreCreateActor(createData, options, userId) {
        //NO-OP
    }
    static async onCreateActor(actor, options, userId) {
        // Return early if we are NOT a GM OR we are not the player that triggered the update AND that player IS a GM
        const user = game.users.get(userId);
        if (!game.user.isGM || (game.userId !== userId && user.isGM)) {
            return;
        }
        // Return early if the actor is not a player character
        if (actor.data.type !== ActorType.Character) {
            return;
        }
        const coreSkills = [
            'Athletics',
            'Common Knowledge',
            'Notice',
            'Persuasion',
            'Stealth',
            'Untrained',
        ];
        //Get and map the existing skills on the actor to an array of names
        const existingSkills = actor.items
            .filter((i) => i.type === ItemType.Skill)
            .map((i) => i.name);
        //Filter the expected
        const skillsToAdd = coreSkills.filter((s) => !existingSkills.includes(s));
        const skillIndex = (await game.packs
            .get('swade.skills')
            .getContent());
        actor.createEmbeddedEntity('OwnedItem', skillIndex.filter((i) => skillsToAdd.includes(i.data.name)));
    }
    static onRenderActorDirectory(app, html, options) {
        // Mark all Wildcards in the Actors sidebars with an icon
        const found = html.find('.entity-name');
        let wildcards = app.entities.filter((a) => a.isWildcard && a.hasPlayerOwner);
        //if the player is not a GM, then don't mark the NPC wildcards
        if (!game.settings.get('swade', 'hideNPCWildcards') || game.user.isGM) {
            const npcWildcards = app.entities.filter((a) => a.isWildcard && !a.hasPlayerOwner);
            wildcards = wildcards.concat(npcWildcards);
        }
        for (let i = 0; i < found.length; i++) {
            const element = found[i];
            const enitityId = element.parentElement.dataset.entityId;
            let wildcard = wildcards.find((a) => a._id === enitityId);
            if (wildcard) {
                element.innerHTML = `
					<a><img src="systems/swade/assets/ui/wildcard.svg" class="wildcard-icon">${wildcard.data.name}</a>
					`;
            }
        }
    }
    static async onRenderCompendium(app, html, data) {
        //Mark Wildcards in the compendium
        if (app.entity === 'Actor') {
            const content = await app.getContent();
            const wildcards = content.filter((entity) => entity.isWildcard);
            const ids = wildcards.map((e) => e._id);
            const found = html.find('.directory-item');
            found.each((i, el) => {
                let entryId = el.dataset.entryId;
                if (ids.includes(entryId)) {
                    const entityName = el.children[1];
                    entityName.children[0].insertAdjacentHTML('afterbegin', '<img src="systems/swade/assets/ui/wildcard-dark.svg" class="wildcard-icon">');
                }
            });
            return false;
        }
    }
    static onPreUpdateActor(actor, updateData, options, userId) {
        //wildcards will be linked, extras unlinked
        if (updateData.data &&
            typeof updateData.data.wildcard !== 'undefined' &&
            game.settings.get('swade', 'autoLinkWildcards')) {
            updateData.token = { actorLink: updateData.data.wildcard };
        }
    }
    static onUpdateActor(actor, updateData, options, userId) {
        var _a;
        if (actor.data.type === ActorType.NPC) {
            ui.actors.render();
        }
        // Update the player list to display new bennies values
        if ((_a = updateData === null || updateData === void 0 ? void 0 : updateData.data) === null || _a === void 0 ? void 0 : _a.bennies) {
            ui['players'].render(true);
        }
    }
    static onRenderCombatTracker(app, html, data) {
        const currentCombat = data.combats[data.currentIndex - 1] || data.combat;
        html.find('.combatant').each((i, el) => {
            const combId = el.getAttribute('data-combatant-id');
            const combatant = currentCombat.combatants.find((c) => c._id == combId);
            const initdiv = el.getElementsByClassName('token-initiative');
            if (combatant.initiative && combatant.initiative !== 0) {
                initdiv[0].innerHTML = `<span class="initiative">${combatant.flags.swade.cardString}</span>`;
            }
            else if (!game.user.isGM) {
                initdiv[0].innerHTML = '';
            }
        });
    }
    static async onPreUpdateCombat(combat, updateData, options, userId) {
        // Return early if we are NOT a GM OR we are not the player that triggered the update AND that player IS a GM
        const user = game.users.get(userId);
        if (!game.user.isGM || (game.userId !== userId && user.isGM)) {
            return;
        }
        // Return if this update does not contains a round
        if (!updateData.round) {
            return;
        }
        if (combat instanceof CombatEncounters) {
            combat = game.combats.get(updateData._id);
        }
        // If we are not moving forward through the rounds, return
        if (updateData.round < 1 || updateData.round < combat.previous.round) {
            return;
        }
        // If Combat has just started, return
        if ((!combat.previous.round || combat.previous.round === 0) &&
            updateData.round === 1) {
            return;
        }
        let jokerDrawn = false;
        // Reset the Initiative of all combatants
        combat.combatants.forEach((c) => {
            if (c.flags.swade && c.flags.swade.hasJoker) {
                jokerDrawn = true;
            }
        });
        const resetComs = combat.combatants.map((c) => {
            c.initiative = 0;
            c.hasRolled = false;
            c.flags.swade.cardValue = null;
            c.flags.swade.suitValue = null;
            c.flags.swade.hasJoker = null;
            return c;
        });
        updateData.combatants = resetComs;
        // Reset the deck if any combatant has had a Joker
        if (jokerDrawn) {
            const deck = game.tables.getName(CONFIG.SWADE.init.cardTable);
            await deck.reset();
            ui.notifications.info('Card Deck automatically reset');
        }
        //Init autoroll
        if (game.settings.get('swade', 'autoInit')) {
            const combatantIds = combat.combatants.map((c) => c._id);
            await combat.rollInitiative(combatantIds);
        }
    }
    static onUpdateCombat(combat, updateData, options, userId) {
        let string = `Round ${combat.round} - Turn ${combat.turn}\n`;
        for (let i = 0; i < combat.turns.length; i++) {
            const element = combat.turns[i];
            string = string.concat(`${i}) ${element['token']['name']}\n`);
        }
        console.log(string);
    }
    static onDeleteCombat(combat, options, userId) {
        if (!game.user.isGM || !game.users.get(userId).isGM) {
            return;
        }
        const jokers = combat.combatants.filter((c) => c.flags.swade && c.flags.swade.hasJoker);
        //reset the deck when combat is ended in a round that a Joker was drawn in
        if (jokers.length > 0) {
            const deck = game.tables.getName(CONFIG.SWADE.init.cardTable);
            deck.reset().then(() => {
                ui.notifications.info('Card Deck automatically reset');
            });
        }
    }
    static async onRenderChatMessage(message, html, data) {
        if (message.isRoll && message.isContentVisible) {
            await formatRoll(message, html, data);
        }
        chat.hideChatActionButtons(message, html, data);
    }
    static async onRenderPlayerList(list, html, options) {
        html.find('.player').each((id, player) => {
            Bennies.append(player, options);
        });
    }
    static onRenderChatLog(app, html, data) {
        chat.chatListeners(html);
    }
    static onGetUserContextOptions(html, context) {
        let players = html.find('#players');
        if (!players)
            return;
        context.push({
            name: game.i18n.localize('SWADE.BenniesGive'),
            icon: '<i class="fas fa-plus"></i>',
            condition: (li) => game.user.isGM && game.users.get(li[0].dataset.userId).isGM,
            callback: (li) => {
                const selectedUser = game.users.get(li[0].dataset.userId);
                selectedUser
                    .setFlag('swade', 'bennies', selectedUser.getFlag('swade', 'bennies') + 1)
                    .then(async () => {
                    ui['players'].render(true);
                    if (game.settings.get('swade', 'notifyBennies')) {
                        //In case one GM gives another GM a benny a different message should be displayed
                        let givenEvent = selectedUser !== game.user;
                        chat.createGmBennyAddMessage(selectedUser, givenEvent);
                    }
                });
            },
        }, {
            name: game.i18n.localize('SWADE.BenniesRefresh'),
            icon: '<i class="fas fa-sync"></i>',
            condition: (li) => game.user.isGM,
            callback: (li) => {
                const user = game.users.get(li[0].dataset.userId);
                Bennies.refresh(user);
            },
        }, {
            name: game.i18n.localize('SWADE.AllBenniesRefresh'),
            icon: '<i class="fas fa-sync"></i>',
            condition: (li) => game.user.isGM,
            callback: (li) => {
                Bennies.refreshAll();
            },
        });
    }
    static onGetSceneControlButtons(sceneControlButtons) {
        const measure = sceneControlButtons.find((a) => a.name === 'measure');
        const newButtons = [
            {
                name: 'swcone',
                title: 'SWADE.Cone',
                icon: 'cone far fa-circle',
                visible: true,
                button: true,
                onClick: () => {
                    const template = SwadeTemplate.fromPreset(TemplatePreset.CONE);
                    if (template)
                        template.drawPreview(event);
                },
            },
            {
                name: 'sbt',
                title: 'SWADE.SBT',
                icon: 'sbt far fa-circle',
                visible: true,
                button: true,
                onClick: () => {
                    const template = SwadeTemplate.fromPreset(TemplatePreset.SBT);
                    if (template)
                        template.drawPreview(event);
                },
            },
            {
                name: 'mbt',
                title: 'SWADE.MBT',
                icon: 'mbt far fa-circle',
                visible: true,
                button: true,
                onClick: () => {
                    const template = SwadeTemplate.fromPreset(TemplatePreset.MBT);
                    if (template)
                        template.drawPreview(event);
                },
            },
            {
                name: 'lbt',
                title: 'SWADE.LBT',
                icon: 'lbt far fa-circle',
                visible: true,
                button: true,
                onClick: () => {
                    const template = SwadeTemplate.fromPreset(TemplatePreset.LBT);
                    if (template)
                        template.drawPreview(event);
                },
            },
        ];
        measure.tools.splice(measure.tools.length - 1, 0, ...newButtons);
    }
    static onDropActorSheetData(actor, sheet, data) {
        if (data.type === 'Actor' && actor.data.type === ActorType.Vehicle) {
            const vehicleSheet = sheet;
            const activeTab = getProperty(vehicleSheet, '_tabs')[0].active;
            if (activeTab === 'summary') {
                vehicleSheet.setDriver(data.id);
            }
            return false;
        }
    }
    static async onRenderCombatantConfig(app, html, options) {
        // resize the element so it'll fit the new stuff
        html.css({ height: 'auto' });
        //remove the old initiative input
        html.find('input[name="initiative"]').parents('div.form-group').remove();
        //grab cards and sort them
        const cardPack = game.packs.get(game.settings.get('swade', 'cardDeck'));
        let cards = (await cardPack.getContent()).sort((a, b) => {
            const cardA = a.getFlag('swade', 'cardValue');
            const cardB = b.getFlag('swade', 'cardValue');
            let card = cardA - cardB;
            if (card !== 0)
                return card;
            const suitA = a.getFlag('swade', 'suitValue');
            const suitB = b.getFlag('swade', 'suitValue');
            let suit = suitA - suitB;
            return suit;
        });
        //prep list of cards for selection
        let cardTable = game.tables.getName(CONFIG.SWADE.init.cardTable);
        let cardList = [];
        for (let card of cards) {
            const cardValue = card.getFlag('swade', 'cardValue');
            const suitValue = card.getFlag('swade', 'suitValue');
            const color = suitValue === 2 || suitValue === 3 ? 'color: red;' : 'color: black;';
            const isDealt = options.object.flags.swade &&
                options.object.flags.swade.cardValue === cardValue &&
                options.object.flags.swade.suitValue === suitValue;
            const isAvailable = cardTable.results.find((r) => r.text === card.name)
                .drawn
                ? 'text-decoration: line-through;'
                : '';
            cardList.push({
                cardValue,
                suitValue,
                isDealt,
                color,
                isAvailable,
                name: card.name,
                cardString: getProperty(card, 'data.content'),
                isJoker: card.getFlag('swade', 'isJoker'),
            });
        }
        const numberOfJokers = cards.filter((c) => c.getFlag('swade', 'isJoker'))
            .length;
        //render and inject new HTML
        const path = 'systems/swade/templates/combatant-config-cardlist.html';
        $(await renderTemplate(path, { cardList, numberOfJokers })).insertBefore(`#${options.options.id} footer`);
        //Attach click event to button which will call the combatant update as we can't easily modify the submit function of the FormApplication
        html.find('footer button').on('click', (ev) => {
            const selectedCard = html.find('input[name=ActionCard]:checked');
            if (selectedCard.length === 0) {
                return;
            }
            const cardValue = selectedCard.data().cardValue;
            const suitValue = selectedCard.data().suitValue;
            const hasJoker = selectedCard.data().isJoker;
            game.combat.updateEmbeddedEntity('Combatant', {
                _id: options.object._id,
                initiative: suitValue + cardValue,
                'flags.swade': {
                    cardValue,
                    suitValue,
                    hasJoker,
                    cardString: selectedCard.val(),
                },
            });
        });
        return false;
    }
}
