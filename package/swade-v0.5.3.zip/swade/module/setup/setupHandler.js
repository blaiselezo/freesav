export async function swadeSetup() {
    console.log("gotcha2");
    const packName = "swade.action-cards";
    if (game.tables.entities.find(t => t.getFlag("swade", "isActionCardDeck"))) {
        return;
    }
    const cardPack = await game.packs.find(p => p.collection === packName).getIndex();
    const tableData = {
        name: "Action Cards",
        replacement: false,
        displayRoll: false,
        type: "base",
        types: "base",
    };
    const tableOptions = { temporary: false, renderSheet: false };
    const table = await RollTable.create(tableData, tableOptions);
    table.setFlag("swade", "isActionCardDeck", true);
    for (let index = 0; index < cardPack.length; index++) {
        let c = cardPack[index];
        let resultData = {
            type: 2,
            text: c.name,
            img: c.img,
            collection: packName,
            resultId: c.id,
            weight: 1,
            range: [index + 1, index + 1]
        };
        await table.createEmbeddedEntity("TableResult", resultData);
    }
    await table.normalize();
    ui.tables.render();
    game.tables.insert(table);
    ui.notifications.info("First-Time-Setup complete");
}
