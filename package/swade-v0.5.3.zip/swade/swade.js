/**
 * This is your TypeScript entry file for Foundry VTT.
 * Register custom settings, sheets, and constants using the Foundry API.
 * Change this heading to be more descriptive to your system, or remove it.
 * Author: FloRad
 * Content License: [copyright and-or license] If using an existing system
 * 					you may want to put a (link to a) license or copyright
 * 					notice here (e.g. the OGL).
 * Software License: [your license] Put your desired license here, which
 * 					 determines how others may use and modify your system
 */
// Import TypeScript modules
import { registerSettings } from "./module/settings.js";
import { registerCustomHelpers } from "./module/handlebarsHelpers.js";
import { preloadHandlebarsTemplates } from "./module/preloadTemplates.js";
import { listenJournalDrop } from "./module/journalDrop.js";
import { SwadeCharacterSheet } from "./module/character-sheet.js";
import { SwadeNPCSheet } from "./module/npc-sheet.js";
import { SwadeItemSheet } from "./module/item-sheet.js";
import { SWADE } from "./module/config.js";
import { isIncapacitated } from "./module/util.js";
import { swadeSetup } from "./module/setup/setupHandler.js";
/* ------------------------------------ */
/* Initialize system					*/
/* ------------------------------------ */
Hooks.once('init', async function () {
    console.log(`SWADE | Initializing Savage Worlds Adventure Edition\n${SWADE.ASCII}`);
    // Record Configuration Values
    CONFIG.SWADE = SWADE;
    //CONFIG.debug.hooks = true;
    //Register custom Handlebars helpers
    registerCustomHelpers();
    // Register custom system settings
    registerSettings();
    // Register custom sheets (if any)
    Actors.unregisterSheet('core', ActorSheet);
    Actors.registerSheet('swade', SwadeCharacterSheet, { types: ['character'], makeDefault: true });
    Actors.registerSheet('swade', SwadeNPCSheet, { types: ['npc'], makeDefault: true });
    Items.unregisterSheet('core', ItemSheet);
    Items.registerSheet('swade', SwadeItemSheet, { makeDefault: true });
    // Drop a journal image to a tile (for cards)
    listenJournalDrop();
    // Preload Handlebars templates
    await preloadHandlebarsTemplates();
});
/* ------------------------------------ */
/* Setup system							*/
/* ------------------------------------ */
Hooks.once('setup', function () {
    // Do anything after initialization but before
    // ready
});
/* ------------------------------------ */
/* When ready							*/
/* ------------------------------------ */
Hooks.once('ready', async () => {
    await swadeSetup();
});
// Add any additional hooks if necessary
Hooks.on('preCreateItem', function (items, item, options) {
    //Set default image if no image already exists
    if (!item.img) {
        item.img = `systems/swade/assets/icons/${item.type}.svg`;
    }
});
// Mark all Wildcards in the Actors sidebars with an icon
Hooks.on('renderActorDirectory', (app, html, data) => {
    const wildcards = app.entities.filter((a) => a.data.type === 'character' || a.getFlag('swade', 'isWildcard'));
    const found = html.find(".entity-name");
    wildcards.forEach((wc) => {
        for (let i = 0; i < found.length; i++) {
            const element = found[i];
            if (element.innerText === wc.data.name) {
                element.innerHTML = `
					<a><img src="systems/swade/assets/ui/wildcard.svg" class="wildcard-icon">${wc.data.name}</a>
					`;
            }
        }
    });
});
Hooks.on('renderCompendium', async (app, html, data) => {
    if (app.metadata.entity !== 'Actor') {
        return;
    }
    const content = await app.getContent();
    const wildcards = content.filter((entity) => entity.data.type === 'character' || entity.getFlag('swade', 'isWildcard'));
    const names = wildcards.map(e => e.data.name);
    const found = html.find('.entry-name');
    found.each((i, el) => {
        const name = names.find(name => name === el.innerText);
        if (!name) {
            return;
        }
        el.innerHTML = `<a><img src="systems/swade/assets/ui/wildcard-dark.svg" class="wildcard-icon">${name}</a>`;
    });
});
Hooks.on('renderActorSheet', (app, html, data) => {
    const actor = data.actor;
    const wounds = actor.data.wounds;
    const fatigue = actor.data.fatigue;
    const isIncap = isIncapacitated(wounds, fatigue);
    if (isIncap) {
        html.find('.incap-img').addClass('fade-in-05');
    }
});
Hooks.on('updateActor', (actor, updates, object, id) => {
    if (actor.data.type === 'npc') {
        ui.actors.render();
    }
});
