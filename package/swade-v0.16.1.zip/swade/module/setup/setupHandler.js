import { createActionCardTable } from "../util.js";
export class SwadeSetup {
    static async setup() {
        if (!game.tables.getName(CONFIG.SWADE.init.cardTable)) {
            await createActionCardTable(CONFIG.SWADE.init.defaultCardCompendium);
            ui.notifications.info('First-Time-Setup complete');
        }
    }
}
