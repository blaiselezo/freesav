export class SWADE {
}
SWADE.ASCII = `███████╗██╗    ██╗ █████╗ ██████╗ ███████╗
██╔════╝██║    ██║██╔══██╗██╔══██╗██╔════╝
███████╗██║ █╗ ██║███████║██║  ██║█████╗  
╚════██║██║███╗██║██╔══██║██║  ██║██╔══╝  
███████║╚███╔███╔╝██║  ██║██████╔╝███████╗
╚══════╝ ╚══╝╚══╝ ╚═╝  ╚═╝╚═════╝ ╚══════╝`;
SWADE.attributes = {
    agility: "SWADE.AttrAgi",
    smarts: "SWADE.AttrSma",
    spirit: "SWADE.AttrSpr",
    strength: "SWADE.AttrStr",
    vigor: "SWADE.AttrVig"
};
SWADE.imagedrop = {
    height: 200
};
