import * as chat from "./chat.js";
import { ActorType } from "./enums/ActorTypeEnum.js";
export default class Bennies {
    static async spendEvent(ev) {
        ev.preventDefault();
        const userId = ev.target.parentElement.dataset.userId;
        const user = game.users.find((user) => user.id == userId);
        if (user.isGM) {
            const value = user.getFlag('swade', 'bennies');
            if (value == 0)
                return;
            const message = await renderTemplate(CONFIG.SWADE.bennies.templates.spend, {
                target: game.user,
                speaker: game.user,
            });
            const chatData = {
                content: message,
            };
            if (game.settings.get('swade', 'notifyBennies')) {
                ChatMessage.create(chatData);
            }
            user.setFlag('swade', 'bennies', value - 1).then(() => {
                if (!!game.dice3d &&
                    game.settings.get('swade', 'dsnShowBennyAnimation')) {
                    const benny = new Roll('1dB').roll();
                    game.dice3d.showForRoll(benny, game.user, true, null, false);
                }
            });
        }
        else if (user.character) {
            user.character.spendBenny();
        }
    }
    /**
     * Refresh the bennies of a character
     * @param user the User the character belongs to
     * @param displayToChat display a message to chat
     *
     */
    static async refresh(user, displayToChat = true) {
        if (user.isGM) {
            await user.setFlag('swade', 'bennies', game.settings.get('swade', 'gmBennies'));
            if (game.settings.get('swade', 'notifyBennies') && displayToChat) {
                const message = await renderTemplate(CONFIG.SWADE.bennies.templates.refresh, { target: user, speaker: game.user });
                const chatData = {
                    content: message,
                };
                ChatMessage.create(chatData);
            }
            ui['players'].render(true);
        }
        if (user.character) {
            user.character.refreshBennies(displayToChat);
        }
    }
    static async refreshAll() {
        for (const user of game.users.values()) {
            this.refresh(user, false);
        }
        const npcWildcardsToRefresh = game.actors.filter((a) => !a.hasPlayerOwner && a.data.type === ActorType.NPC && a.isWildcard);
        for (const actor of npcWildcardsToRefresh) {
            await actor.refreshBennies(false);
        }
        if (game.settings.get('swade', 'notifyBennies')) {
            const message = await renderTemplate(CONFIG.SWADE.bennies.templates.refreshAll, {});
            const chatData = {
                content: message,
            };
            ChatMessage.create(chatData);
        }
    }
    static async giveEvent(ev) {
        ev.preventDefault();
        const userId = ev.target.parentElement.dataset.userId;
        const user = game.users.find((user) => user.id == userId);
        if (user.isGM) {
            await user.setFlag('swade', 'bennies', user.getFlag('swade', 'bennies') + 1);
            if (game.settings.get('swade', 'notifyBennies')) {
                chat.createGmBennyAddMessage(user, true);
            }
            ui['players'].render(true);
        }
        else if (user.character) {
            user.character.getBenny();
        }
    }
    static updateBenny(ev) {
        const userId = ev.target.parentElement.dataset.userId;
        const user = game.users.find((user) => user.id == userId);
        if (user.isGM) {
            const value = user.getFlag('swade', 'bennies');
            ev.target.innerHTML = value.toString();
        }
        else if (user.character) {
            ev.target.innerHTML =
                user.character.data.data.bennies.value;
        }
    }
    static append(player, options) {
        const user = options.users.find((user) => user.id == player.dataset.userId);
        const span = document.createElement('span');
        span.classList.add('bennies-count');
        // Player view
        if (!game.user.isGM) {
            if (user.isGM) {
                span.innerHTML = user.getFlag('swade', 'bennies');
            }
            else if (user.character) {
                span.onmouseleave = Bennies.updateBenny;
                span.onclick = this.spendEvent;
                span.onmouseover = () => {
                    span.innerHTML = '-';
                };
                span.title = game.i18n.localize('SWADE.BenniesSpend');
                span.innerHTML = user.character.data.data.bennies.value;
            }
            else {
                return;
            }
            player.append(span);
            return;
        }
        // GM interactive interface
        span.classList.add('bennies-gm');
        span.onmouseleave = Bennies.updateBenny;
        span.onclick = user.isGM ? this.spendEvent : this.giveEvent;
        span.onmouseover = () => {
            span.innerHTML = user.isGM ? '-' : '+';
        };
        span.title = user.isGM
            ? game.i18n.localize('SWADE.BenniesSpend')
            : game.i18n.localize('SWADE.BenniesGive');
        // Manage GM Bennies
        if (user.isGM) {
            const bennies = user.getFlag('swade', 'bennies');
            // Set bennies to number as defined in GM benny setting
            if (bennies == null) {
                user
                    .setFlag('swade', 'bennies', game.settings.get('swade', 'gmBennies'))
                    .then(() => {
                    span.innerHTML = game.settings.get('swade', 'gmBennies').toString();
                    player.append(span);
                });
            }
            else {
                span.innerHTML = user.getFlag('swade', 'bennies');
                player.append(span);
            }
        }
        else if (user.character) {
            span.innerHTML = user.character.data.data.bennies.value;
            player.append(span);
        }
    }
}
