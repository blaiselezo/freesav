import { createActionCardTable } from "../util.js";
export class SwadeSetup {
    static async setup() {
        if (!game.tables.getName(CONFIG.SWADE.init.cardTable)) {
            await createActionCardTable();
            ui.notifications.info('First-Time-Setup complete');
        }
    }
}
