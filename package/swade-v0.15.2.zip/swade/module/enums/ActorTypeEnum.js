export var ActorType;
(function (ActorType) {
    ActorType["Character"] = "character";
    ActorType["NPC"] = "npc";
    ActorType["Vehicle"] = "vehicle";
})(ActorType || (ActorType = {}));
