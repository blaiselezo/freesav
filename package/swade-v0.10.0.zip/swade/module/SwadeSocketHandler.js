export class SwadeSocketHandler {
    constructor() {
        this.SWADE = 'system.swade';
        //register socket listeners
        this.registerSocketListeners();
    }
    /**
     * registers all the socket listeners
     */
    registerSocketListeners() {
        game.socket.on(this.SWADE, (data) => {
            switch (data.type) {
                case 'deleteConvictionMessage':
                    this._onDeleteConvictionMessage(data);
                    break;
                case 'newRound':
                    this._onNewRound();
                    break;
                default:
                    this._onUnknownSocket();
                    break;
            }
        });
    }
    deleteConvictionMessage(messageId) {
        game.socket.emit(this.SWADE, {
            type: 'deleteConvictionMessage',
            messageId,
            userId: game.userId,
        });
    }
    _onDeleteConvictionMessage(data) {
        const message = game.messages.get(data.messageId);
        //only delete the message if the user is a GM and the event emitter is one of the recipients
        if (game.user.isGM && message.data['whisper'].includes(data.userId)) {
            message.delete();
        }
    }
    newRound() {
        game.socket.emit(this.SWADE, {
            type: 'newRound',
        });
    }
    _onNewRound() { }
    _onUnknownSocket() {
        throw new Error('This socket event is not supported');
    }
}
