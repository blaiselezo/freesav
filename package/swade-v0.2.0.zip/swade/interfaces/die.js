export class Die {
}
