export class Die {
    constructor() {
        this.amount = 0;
        this.sides = 0;
        this.modifier = 0;
        this.modifiers = [];
    }
    toString() {
        return `[amount] = ${this.amount}\n[sides] = ${this.sides}\n[modifier] = ${this.modifier}\n[modifiers] = ${this.modifiers}`;
    }
}
