export class SwadeInitiative {
}
